package com.example.lock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()